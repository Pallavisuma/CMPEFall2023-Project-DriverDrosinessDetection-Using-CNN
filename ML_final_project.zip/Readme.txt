execution instructions
  Install required packages
 
   1) install CV2
           pip install CV2
   2) install keras
           pip install keras
   3) install tensorflow
           pip install tensorflow
   4) install numpy 
           pip install numpy
   5) install pygame
           pip install pygame
After installing all the required files run main.py file
