execution instructions
the saved model "cnnimg.h5" file was 35MB so we couldn't upload it in github. Here is the drive link https://drive.google.com/file/d/1DcGq14XoeoJM3kwhklWmg0cToCSSmZpt/view?usp=sharing
download this file and save it in the same directory of main.py file.

  Install required packages
 
   1) install CV2
           pip install CV2
   2) install keras
           pip install keras
   3) install tensorflow
           pip install tensorflow
   4) install numpy 
           pip install numpy
   5) install pygame
           pip install pygame
   6) install time
           pip install time
After installing all the required files run main.py file
