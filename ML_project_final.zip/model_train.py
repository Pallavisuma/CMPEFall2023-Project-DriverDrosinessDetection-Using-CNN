import os
import matplotlib.pyplot as plt 
import numpy as np
import random, shutil
from keras.preprocessing import image
from keras.utils.np_utils import to_categorical
from keras.models import Sequential
from keras.layers import Dropout, Conv2D, Flatten, Dense, MaxPooling2D, BatchNormalization
from keras.models import load_model
'''
# Function for generating data batches
def generator(dir, gen=image.ImageDataGenerator(rescale=1./255), shuffle=True, batch_size=1, target_size=(24,24), class_mode='categorical'):
    return gen.flow_from_directory(dir, batch_size=batch_size, shuffle=shuffle, color_mode='grayscale', class_mode=class_mode, target_size=target_size)

Batch_size = 32
Img_shape = (24, 24)

# Generating training and validation batches for eyes and mouth classification
train_batch = generator('data/train', shuffle=True, batch_size=Batch_size, target_size=Img_shape)
valid_batch = generator('data/valid', shuffle=True, batch_size=Batch_size, target_size=Img_shape)
'''

Batch_size = 32
Img_shape = (24, 24)
# Function for generating data batches (for both training and validation)
def custom_generator(directory, batch_size=32, target_size=(24, 24)):
    while True:
        files = []
        labels = []
        for folder in sorted(os.listdir(directory)):
            folder_path = os.path.join(directory, folder)
            if os.path.isdir(folder_path):
                for file in os.listdir(folder_path):
                    if file.endswith(".jpg") or file.endswith(".png"):  # Include relevant file extensions
                        img_path = os.path.join(folder_path, file)
                        img = image.load_img(img_path, target_size=target_size, color_mode="grayscale")
                        img_array = image.img_to_array(img)
                        img_array /= 255.0  # Normalize pixel values
                        files.append(img_array)
                        labels.append(int(folder[1:]))  # Extract numeric label from folder name 'sXXXX'

                        if len(files) >= batch_size:
                            yield np.array(files), np.array(labels)
                            files = []
                            labels = []

        if files:  # Yield remaining data
            yield np.array(files), np.array(labels)

train_data_directory = 'path/to/your/train/folder'
train_batch = custom_generator(train_data_directory, batch_size=32, target_size=(24, 24))
validation_data_directory = 'path/to/your/validation/folder'
valid_batch = custom_generator(validation_data_directory, batch_size=32, target_size=(24, 24))

# Steps per epoch for training and validation
Steps = len(train_batch.classes) // Batch_size
Valid_steps = len(valid_batch.classes) // Batch_size
print(Steps, Valid_steps)

# Model architecture for eyes and mouth classification
model = Sequential([
    Conv2D(32, kernel_size=(3, 3), activation='relu', input_shape=(24, 24, 1)),
    MaxPooling2D(pool_size=(1, 1)),
    Conv2D(32, (3, 3), activation='relu'),
    MaxPooling2D(pool_size=(1, 1)),
    Conv2D(64, (3, 3), activation='relu'),
    MaxPooling2D(pool_size=(1, 1)),
    
    Dropout(0.25),
    Flatten(),
    
    Dense(128, activation='relu'),
    Dropout(0.5),
    Dense(4, activation='softmax')  # Output layer with 4 neurons for eyes and mouth (2 classes each)
])

model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

# Training the model for eyes and mouth classification
model.fit_generator(train_batch, validation_data=valid_batch, epochs=15, steps_per_epoch=Steps, validation_steps=Valid_steps)

# Saving the trained model
model.save('models/cnn_eyes_mouth.h5', overwrite=True)
